<?php require 'includes/header_account.php'; ?>

    <div class="ex-page-content text-xs-center">
        <div class="text-error shadow">500</div>
        <h3 class="text-uppercase text-white font-600">Internal Server Error</h3>
        <p class="text-white m-t-30">
            Why not try refreshing your page? or you can contact <a href=""
                                                                    class="text-white text-uppercase"><b>support</b></a>
        </p>
        <br>
        <a class="btn btn-pink waves-effect waves-light" href="index.php"> Return Home</a>

    </div>


    </div>
    <!-- end wrapper page -->

<?php require 'includes/footer_account.php'; ?>